"use strict";

//MAIN
var oEmpresa = new Empresa();

registrarEventos();
ocultarFormularios();

function registrarEventos() {
  document
    .querySelector("#mnuCrearProyecto")
    .addEventListener("click", mostrarFormulario);
  document
    .querySelector("#mnuAñadirRecurso")
    .addEventListener("click", mostrarFormulario);
  document
    .querySelector("#mnuListadoProyectos")
    .addEventListener("click", mostrarListadoProyectos);
  document
    .querySelector("#mnuBuscarProyecto")
    .addEventListener("click", mostrarFormulario);

  //Botones
  frmCrearProyecto.btnAltaProyecto.addEventListener(
    "click",
    procesarAltaProyecto
  );
  frmAñadirRecurso.btnAltaRecurso.addEventListener(
    "click",
    procesarAltaRecurso
  );
  frmBuscarProyecto.btnBuscarProyecto.addEventListener(
    "click",
    procesarBuscarProyecto
  );
}

function mostrarFormulario(oEvento) {
  let opcionMenu = oEvento.target.id;
  ocultarFormularios();

  switch (opcionMenu) {
    case "mnuCrearProyecto":
      frmCrearProyecto.style.display = "block";
      break;
    case "mnuAñadirRecurso":
      frmAñadirRecurso.style.display = "block";
      break;
    case "mnuBuscarProyecto":
      frmBuscarProyecto.style.display = "block";
      break;
  }
}

function ocultarFormularios() {
  frmCrearProyecto.style.display = "none";
  frmAñadirRecurso.style.display = "none";
  frmBuscarProyecto.style.display = "none";

  document.querySelector("#resultadoBusqueda").innerHTML = "";
  document.querySelector("#listados").innerHTML = "";
}

async function procesarAltaProyecto() {
  let proyecto_id = parseInt(frmCrearProyecto.idProyecto.value.trim());
  let proyecto_nombre = frmCrearProyecto.nombreProyecto.value.trim();
  let proyecto_fecha_inicio = frmCrearProyecto.fechaInicio.value.trim();
  let proyecto_fecha_fin = frmCrearProyecto.fechaFin.value.trim();
  let proyecto_descripcion = frmCrearProyecto.descripcion.value.trim();
  let proyecto_cliente = frmCrearProyecto.cliente.value.trim();
  let proyecto_estado = frmCrearProyecto.estado.value.trim();

  if (validarAltaProyecto()) {
    let respuesta = await oEmpresa.altaProyecto(
      new Proyecto(
        proyecto_id,
        proyecto_nombre,
        proyecto_fecha_inicio,
        proyecto_fecha_fin,
        proyecto_descripcion,
        proyecto_cliente,
        proyecto_estado
      )
    );

    alert(respuesta.mensaje);

    if (!respuesta.error) {
      // Si NO hay error
      //Resetear formulario
      frmCrearProyecto.reset();
      // Ocultar el formulario
      frmCrearProyecto.style.display = "none";
    }
  }
}

function validarAltaProyecto() {
  let proyecto_id = frmCrearProyecto.idProyecto.value.trim();
  let proyecto_nombre = frmCrearProyecto.nombreProyecto.value.trim();
  let proyecto_fecha_inicio = frmCrearProyecto.fechaInicio.value.trim();
  let proyecto_fecha_fin = frmCrearProyecto.fechaFin.value.trim();
  let proyecto_descripcion = frmCrearProyecto.descripcion.value.trim();
  let proyecto_cliente = frmCrearProyecto.cliente.value.trim();
  let proyecto_estado = frmCrearProyecto.estado.value.trim();

  let valido = true;
  let errores = "";

  // if (proyecto_nombre.length == 0 || proyecto_descripcion.length == 0 || proyecto_cliente.length == 0 || proyecto_estado.length == 0) {
  //     valido = false;
  //     errores += "No puede haber campos vacíos";
  // }

  return valido;
}

async function procesarAltaRecurso() {
  let recurso_nombre = frmAñadirRecurso.nombreRecurso.value.trim();
  let recurso_tipo = frmAñadirRecurso.tipoRecurso.value.trim();
  let recurso_proyecto_id = frmAñadirRecurso.idProyecto.value.trim();

  if (validarAltaRecurso()) {
    let respuesta = await oEmpresa.altaRecurso(
      new Recurso(null, recurso_nombre, recurso_tipo, recurso_proyecto_id)
    );
    alert(respuesta.mensaje);

    if (!respuesta.error) {
      // Si NO hay error
      //Resetear formulario
      frmAñadirRecurso.reset();
      // Ocultar el formulario
      frmAñadirRecurso.style.display = "none";
    }
  }
}

function validarAltaRecurso() {
  let recurso_nombre = frmAñadirRecurso.nombreRecurso.value.trim();
  let recurso_tipo = frmAñadirRecurso.tipoRecurso.value.trim();
  let recurso_proyecto_id = parseInt(frmAñadirRecurso.idProyecto.value.trim());

  let valido = true;
  let errores = "";

  if (
    recurso_nombre.length == 0 ||
    recurso_tipo.length == 0 ||
    recurso_proyecto_id.length == 0
  ) {
    valido = false;
    errores += "No puede haber campos vacíos";
  }

  return valido;
}

function mostrarListadoProyectos() {
  open("listado_proyectos.html");
}

async function procesarBuscarProyecto() {
  if (validarBuscarProyecto()) {
    let proyecto_id = parseInt(frmCrearProyecto.idProyecto.value.trim());

    let respuesta = await oEmpresa.buscarProyecto(proyecto_id);

    if (!respuesta.error) {
      // Si NO hay error
      let resultadoBusqueda = document.querySelector("#resultadoBusqueda");

      // Escribimos resultado
      let tablaSalida = "<table class='table'>";
      tablaSalida +=
        "<thead><tr><th>ID_PROYECTO</th><th>NOMBRE</th><th>DESCRIPCION</th></tr></thead>";
      tablaSalida += "<tbody><tr>";
      tablaSalida += "<td>" + respuesta.datos.proyecto_id + "</td>";
      tablaSalida += "<td>" + respuesta.datos.proyecto_nombre + "</td>";
      tablaSalida += "<td>" + respuesta.datos.proyecto_descripcion + "</td>";

      tablaSalida +=
        "<td><input type='button' class='btn btn-danger' value='Borrar' id='btnBorrarProyecto' data-proyecto_id='" +
        respuesta.datos.proyecto_id +
        "'></td>";
      tablaSalida += "</tr></tbody></table>";

      resultadoBusqueda.innerHTML = tablaSalida;
      // resultadoBusqueda.style.display = "block";

      // // Registrar evento para el botón borrar
      // document.querySelector("#btnBorrarProyecto").addEventListener("click", borrarProyecto);
    } else {
      // Si hay error
      alert(respuesta.mensaje);
    }
  }
}

function validarBuscarProyecto() {
  let proyecto_id = parseInt(frmBuscarProyecto.idProyecto.value.trim());
  let valido = true;
  let errores = "";

  if (isNaN(proyecto_id)) {
    valido = false;
    errores += "El ID del proyecto debe ser un número";
  }

  if (!valido) {
    // Hay errores
    alert(errores);
  }
  return valido;
}
