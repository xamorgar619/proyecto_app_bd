//objetos.js

class Proyecto {
  constructor(
    proyecto_id,
    proyecto_nombre,
    proyecto_fecha_inicio,
    proyecto_fecha_fin,
    proyecto_descripcion,
    proyecto_cliente,
    proyecto_estado
  ) {
    this.proyecto_id = proyecto_id;
    this.proyecto_nombre = proyecto_nombre;
    this.proyecto_fecha_inicio = proyecto_fecha_inicio;
    this.proyecto_fecha_fin = proyecto_fecha_fin;
    this.proyecto_descripcion = proyecto_descripcion;
    this.proyecto_cliente = proyecto_cliente;
    this.proyecto_estado = proyecto_estado;
  }
}

class Recurso {
  constructor(
    recurso_id,
    recurso_nombre,
    recurso_tipo,
    recurso_proyecto_id,
  ) {
    this.recurso_id = recurso_id;
    this.recurso_nombre = recurso_nombre;
    this.recurso_tipo = recurso_tipo;
    this.recurso_proyecto_id = recurso_proyecto_id;
  }
}

class Empresa {
  async altaRecurso(oRecurso) {
    let datos = new FormData();

    datos.append("recurso_nombre", oRecurso.recurso_nombre);
    datos.append("recurso_tipo", oRecurso.recurso_tipo);
    datos.append("recurso_proyecto_id", oRecurso.recurso_proyecto_id);

    let respuesta = await peticionPOST("alta_recurso.php", datos);

    return respuesta;
  }

  async altaProyecto(oProyecto) {
    let datos = new FormData();

    datos.append("proyecto_id", oProyecto.proyecto_id);
    datos.append("proyecto_nombre", oProyecto.proyecto_nombre);
    datos.append("proyecto_fecha_inicio", oProyecto.proyecto_fecha_inicio);
    datos.append("proyecto_fecha_fin", oProyecto.proyecto_fecha_fin);
    datos.append("proyecto_descripcion", oProyecto.proyecto_descripcion);
    datos.append("proyecto_cliente", oProyecto.proyecto_cliente);
    datos.append("proyecto_estado", oProyecto.proyecto_estado);

    let respuesta = await peticionPOST("alta_proyecto.php", datos);

    return respuesta;
  }

  async listadoProyectos() {
    let listado = "";

    let respuesta = await peticionGET("get_proyectos.php", new FormData());

    if (!respuesta.error) {
      listado = respuesta.mensaje;
    } else {
        listado = "<table class='table table-striped'>";
        listado +=
            "<thead><tr><th>IDPROYECTO</th><th>NOMBRE</th><th>DESCRIPCIÓN</th></tr></thead>";
        listado += "<tbody>";

        for (let proyecto of respuesta.datos) {
            listado += "<tr>";
            listado += "<td>" + proyecto.proyecto_id + "</td>";
            listado += "<td>" + proyecto.proyecto_nombre + "</td>";
            listado += "<td>" + proyecto.proyecto_descripcion + "</td>";
            listado += "</tr>";
        }
        listado += "</tbody></table>";
    }

    return listado;
  }

  async buscarProyecto(proyecto_id) {
    let datos = new FormData();

    datos.append("proyecto_id", proyecto_id);

    let respuesta = await peticionPOST("buscar_proyecto.php", datos);

    return respuesta;
}

}
