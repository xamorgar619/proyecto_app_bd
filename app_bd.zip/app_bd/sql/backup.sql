-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: db
-- Tiempo de generación: 30-11-2023 a las 20:13:02
-- Versión del servidor: 8.1.0
-- Versión de PHP: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `PROYECTO`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Proyecto`
--

CREATE TABLE `Proyecto` (
  `proyecto_id` int NOT NULL,
  `proyecto_nombre` varchar(255) DEFAULT NULL,
  `proyecto_fecha_inicio` date DEFAULT NULL,
  `proyecto_fecha_fin` date DEFAULT NULL,
  `proyecto_descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `proyecto_cliente` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `proyecto_estado` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Proyecto`
--

INSERT INTO `Proyecto` (`proyecto_id`, `proyecto_nombre`, `proyecto_fecha_inicio`, `proyecto_fecha_fin`, `proyecto_descripcion`, `proyecto_cliente`, `proyecto_estado`) VALUES
(1, 'Proyecto 1', '2022-03-10', '2023-11-11', 'UMP', 'Descripción del proyecto 1', 'Finalizado'),
(2, 'Proyecto 2', '2023-11-23', '2025-11-04', 'Javier Pérez S.A', 'Descripción del proyecto 2', 'En Curso'),
(3, 'Proyecto 3', '2020-12-02', '2023-10-13', 'UMP', 'Descripción del proyecto 3', 'Finalizado'),
(4, 'Proyecto 4', '2023-11-04', '2024-10-01', 'Luis García S.A', 'Descripción del proyecto 4', 'En Curso'),
(5, 'Proyecto 5', '2021-05-18', '2023-08-29', 'UMP', 'Descripción del proyecto 5', 'Finalizado'),
(6, 'Proyecto 6', '2021-06-12', '2023-09-23', 'UMP', 'Descripción del proyecto 6', 'Finalizado'),
(7, 'Proyecto 7', '2022-08-08', '2023-07-02', 'Rodaballo S.A', 'Descripción del proyecto 7', 'Finalizado'),
(8, 'Proyecto 8', '2020-08-11', '2022-12-23', 'Antonio Lucas', 'Descripción del proyecto 8', 'Finalizado'),
(9, 'Proyecto 9', '2019-04-06', '2022-05-07', 'Bárbara S.A', 'Descripción del proyecto 9', 'Finalizado'),
(10, 'Proyecto 10', '2021-10-17', '2023-10-13', 'UMP', 'Descripción del proyecto 10', 'Finalizado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Recurso`
--

CREATE TABLE `Recurso` (
  `recurso_id` int NOT NULL,
  `recurso_nombre` varchar(255) DEFAULT NULL,
  `recurso_tipo` varchar(50) DEFAULT NULL,
  `proyecto_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `Recurso`
--

INSERT INTO `Recurso` (`recurso_id`, `recurso_nombre`, `recurso_tipo`, `proyecto_id`) VALUES
(7, 'Ladrillos', 'Material', 1),
(8, 'Hormigón', 'Equipo', 3),
(9, 'Hormigonera', 'Equipo', 3),
(10, 'Pala', 'Equipo', 3),
(11, 'Ladrillos', 'Material', 3),
(12, 'Hormigón', 'Material', 7),
(13, 'Hormigonera', 'Equipo', 7),
(14, 'Grúa', 'Equipo', 7),
(15, 'Pala', 'Equipo', 9),
(16, 'Ladrillos', 'Material', 6);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Proyecto`
--
ALTER TABLE `Proyecto`
  ADD PRIMARY KEY (`proyecto_id`);

--
-- Indices de la tabla `Recurso`
--
ALTER TABLE `Recurso`
  ADD PRIMARY KEY (`recurso_id`),
  ADD KEY `proyecto_id` (`proyecto_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Recurso`
--
ALTER TABLE `Recurso`
  MODIFY `recurso_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Recurso`
--
ALTER TABLE `Recurso`
  ADD CONSTRAINT `Recurso_ibfk_1` FOREIGN KEY (`proyecto_id`) REFERENCES `Proyecto` (`proyecto_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
