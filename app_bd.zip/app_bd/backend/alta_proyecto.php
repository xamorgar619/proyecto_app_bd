<?php
include_once("config.php");
$conexion = obtenerConexion();

// Recoger datos
$proyecto_id = $_POST["proyecto_id"];
$proyecto_nombre = $_POST["proyecto_nombre"];
$proyecto_descripcion = $_POST["proyecto_descripcion"];
$proyecto_fecha_inicio = $_POST["proyecto_fecha_inicio"];
$proyecto_fecha_fin = $_POST["proyecto_fecha_fin"];
$proyecto_cliente = $_POST["proyecto_cliente"];
$proyecto_estado = $_POST["proyecto_estado"];


$sql = "INSERT INTO Proyecto VALUES ('$proyecto_id', '$proyecto_nombre', '$proyecto_fecha_inicio', '$proyecto_fecha_fin', '$proyecto_cliente', '$proyecto_descripcion', '$proyecto_estado');";

mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    responder(null, true, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    // Prototipo responder($datos,$error,$mensaje,$conexion)
    responder(null, false, "Se ha creado el proyecto", $conexion);
}
?>