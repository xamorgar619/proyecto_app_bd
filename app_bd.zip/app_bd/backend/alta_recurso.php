<?php
include_once("config.php");
$conexion = obtenerConexion();

// Recoger datos
$recurso_nombre = $_POST["recurso_nombre"];
$recurso_tipo = $_POST["recurso_tipo"];
$proyecto_id = $_POST["recurso_proyecto_id"];

$sql = "INSERT INTO Recurso VALUES (null, '$recurso_nombre', '$recurso_tipo', '$proyecto_id');";

mysqli_query($conexion, $sql);

if (mysqli_errno($conexion) != 0) {
    $numerror = mysqli_errno($conexion);
    $descrerror = mysqli_error($conexion);

    responder(null, true, "Se ha producido un error número $numerror que corresponde a: $descrerror <br>", $conexion);

} else {
    // Prototipo responder($datos,$error,$mensaje,$conexion)
    responder(null, false, "Se ha insertado el recurso", $conexion);
}
?>