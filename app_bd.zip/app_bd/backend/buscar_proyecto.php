<?php
require_once('config.php');
$conexion = obtenerConexion();

// Datos de entrada
$proyecto_id = $_POST["proyecto_id"];

// SQL
$sql = "SELECT * FROM Proyecto WHERE proyecto_id = $proyecto_id;";

$resultado = mysqli_query($conexion, $sql);

// Pedir una fila
$fila = mysqli_fetch_assoc($resultado);

if($fila){ // Devuelve datos
    // responder(datos, error, mensaje, conexion)
    responder($fila, false, "Datos recuperados", $conexion);
} else { // No hay datos
    responder(null, true, "No existe el componente", $conexion);
}