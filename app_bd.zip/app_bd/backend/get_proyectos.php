<?php
require_once('config.php');
$conexion = obtenerConexion();


$sql = "SELECT * FROM Proyecto;";

$resultado = mysqli_query($conexion, $sql);

while ($fila = mysqli_fetch_assoc($resultado)) {
    $datos[] = $fila; // Insertar la fila en el array
}

responder($datos, false, "Datos recuperados", $conexion);